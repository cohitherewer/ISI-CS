#include "add.h"
int main(int argc, char **argv) {
CLIENT *cl;
intpair in;
int *out;
if (argc!=4)
{
printf("Usage:...\n");
return 1;
}
cl = clnt_create(argv[1], ADD_PROG, ADD_VERS, "tcp");
in.a = atol(argv[2]);
in.b = atol(argv[3]);
out = add_1(&in, cl);
if (out == NULL)
{
printf("Error: %s\n", clnt_sperror(cl, argv[1]));
}
else
{
printf("We received the result: %d\n", *out);
}
clnt_destroy(cl);
return 0;
}
