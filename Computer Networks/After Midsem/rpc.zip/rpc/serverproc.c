#include "add.h"
int *add_1_svc(intpair *in, struct svc_req *rqstp) {
static int out;
out = in->a + in->b;
return(&out);
}
